const search = () => {
	let input = document.getElementById("text").value.toUpperCase();
	let table = document.getElementById("table");
	let tr = table.getElementsByTagName("tr");
	for (var i = 0; i < tr.length; i++) {
		let td = tr[i].getElementsByTagName("td")[1];
		if (td) {
			let textvalue = td.textContent;
			if (textvalue.toUpperCase().indexOf(input) > -1) {
				tr[i].style.display = "";
			} else {
				tr[i].style.display = "none";
			}
		}
	}
}