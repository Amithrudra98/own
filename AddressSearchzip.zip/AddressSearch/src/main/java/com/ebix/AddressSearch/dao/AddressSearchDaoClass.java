package com.ebix.AddressSearch.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ebix.AddressSearch.bean.AddressBean;
import com.ebix.AddressSearch.bean.UserLoginBean;

@Repository
public class AddressSearchDaoClass implements AddressSearchDaoInterface {

	EntityManagerFactory factory;
	EntityManager manager;
	EntityTransaction transaction;
	UserLoginBean loginBean;

	public void init() {
		factory = Persistence.createEntityManagerFactory("address");
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
	}

	@Override
	public UserLoginBean validateuser(String username, String password) {
		init();
		transaction.begin();
		loginBean = manager.find(UserLoginBean.class, username);
		if (loginBean.getUserName() != null && loginBean.getUserName().equals(username)) {
			if (loginBean.getPassword() != null && loginBean.getPassword().equals(password)) {
				display();
				return loginBean;
			} else {
				return null;
			}
		} else {
			return null;
		}
	}

	@Override
	public boolean adduser(UserLoginBean loginBean) {
		init();
		boolean isAdded = false;
		try {
			transaction.begin();
			manager.persist(loginBean);
			transaction.commit();
			isAdded = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isAdded;
	}

	@Override
	public List<AddressBean> display() {
		init();
		String query = "from AddressBean";
		Query query2 = manager.createQuery(query);
		List<AddressBean> list = query2.getResultList();
		if (list != null) {
			return list;
		} else {
			return null;
		}
	}

}
