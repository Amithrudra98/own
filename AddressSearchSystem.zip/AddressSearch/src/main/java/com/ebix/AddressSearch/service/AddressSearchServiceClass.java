package com.ebix.AddressSearch.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ebix.AddressSearch.bean.AddressBean;
import com.ebix.AddressSearch.bean.UserLoginBean;
import com.ebix.AddressSearch.dao.AddressSearchDaoInterface;

@Service
public class AddressSearchServiceClass implements AddressSearchServiceInterface {

	@Autowired
	AddressSearchDaoInterface daoInterface;

	@Override
	public UserLoginBean validateuser(String username, String password) {
		if (username != null && password != null) {
			return daoInterface.validateuser(username, password);
		} else {
			return null;
		}
	}

	@Override
	public boolean adduser(UserLoginBean loginBean) {
		if (loginBean != null) {
			return daoInterface.adduser(loginBean);
		} else {
			return false;
		}
	}

	@Override
	public List<AddressBean> display() {
		return daoInterface.display();
	}

}
