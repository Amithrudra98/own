package com.ebix.AddressSearch.service;

import java.util.List;

import com.ebix.AddressSearch.bean.AddressBean;
import com.ebix.AddressSearch.bean.UserLoginBean;

public interface AddressSearchServiceInterface {

	public UserLoginBean validateuser(String username, String password);

	public boolean adduser(UserLoginBean loginBean);

	public List<AddressBean> display();

}
