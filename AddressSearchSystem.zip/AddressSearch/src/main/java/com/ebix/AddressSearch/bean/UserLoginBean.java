package com.ebix.AddressSearch.bean;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "user_info")
public class UserLoginBean implements Serializable {

	@Id
	private String userName;
	private String password;

}
