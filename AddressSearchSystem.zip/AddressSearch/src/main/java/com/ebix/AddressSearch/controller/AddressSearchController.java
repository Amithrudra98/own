package com.ebix.AddressSearch.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttribute;

import com.ebix.AddressSearch.bean.AddressBean;
import com.ebix.AddressSearch.bean.UserLoginBean;
import com.ebix.AddressSearch.service.AddressSearchServiceInterface;

@Controller
public class AddressSearchController {

	UserLoginBean userBean;

	@Autowired
	AddressSearchServiceInterface serviceinterface;

	@GetMapping("/login")
	public String displaylogin() {
		return "login";
	}

	@PostMapping("/login")
	public String validateuser(ModelMap map, String userName, String password, HttpServletRequest request,
			HttpServletResponse response) {
		userBean = serviceinterface.validateuser(userName, password);
		if (userBean != null) {
			HttpSession session = request.getSession();
			session.setAttribute("loggedin", userBean);
			List<AddressBean> beans = serviceinterface.display();
			request.setAttribute("list", beans);
			map.addAttribute("msg", "Logged In Successfully");
			return "home";
		} else {
			map.addAttribute("errmsg", "Invalid credentials");
			return "login";
		}
	}

	@GetMapping("/logout")
	public String Logout(ModelMap map, HttpSession session,
			@SessionAttribute(name = "loggedin", required = false) UserLoginBean loginBean) {
		session.invalidate();
		if (loginBean != null) {
			map.addAttribute("msg", "logged out successfully");
			return "login";
		} else {
			map.addAttribute("msg", "Please login first");
			return "login";
		}
	}

	@GetMapping("/registeruser")
	public String register() {
		return "registerpage";
	}

	@PostMapping("/registeruser")
	public String registeruser(ModelMap map, UserLoginBean loginBean) {

		if (serviceinterface.adduser(loginBean)) {
			map.addAttribute("msg", "User Added Successfully");
			return "login";
		} else {
			map.addAttribute("msg", "Something Went Wrong");
			return "registerpage";
		}
	}

}
